import webbrowser
class Movie():
    """
    class movie used for new movies
    takes 5 params at init
    movie_title,movie_storyline,poster_image,trailer_youtube,launch_date
    """

    def __init__(self, movie_title, movie_storyline, poster_image, trailer_youtube, launch_date):
        """
        intialization of Movie class
        takes input like movie_title and so on
        """
        self.title = movie_title
        self.storyline = movie_storyline
        self.poster_image_url = poster_image
        self.trailer_youtube_url = trailer_youtube
        self.launch_date = launch_date
        
    def show_trailer(self):
        """
        return trailer of movie
        """
        webbrowser.open(self.trailer_youtube_url)
