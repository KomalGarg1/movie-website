import fresh_tomatoes
import media
tiger_zinda_hai = media.Movie("Tiger Zinda Hai",#return title of movie
                              "RAW Agent Tiger joins forces with Zoya, a Pakistani spy, in order to rescue a group of nurses who are held hostage by a terrorist organisation.",#return storyline of movie
                              "https://i.ebayimg.com/images/g/kfcAAOSwa0VaG8u6/s-l300.jpg",#return poster of the movie
                              "https://youtu.be/ePO5M5DE01I",#return trailer of the movie
                              "22,December,2017")#return launch date of movie
it = media.Movie("It",
                 "Seven young outcasts in Derry, Maine, are about to face their worst nightmare ",
                 "https://pre00.deviantart.net/8c0b/th/pre/f/2017/057/7/0/it___it___a_coisa__2017__poster_by_netoribeiro89-db0gzuc.jpg",
                 "https://www.youtube.com/watch?v=FnCdOQsX5kc",
                 "8,September,2017")

harry_potter = media.Movie("Harry potter",
                           "Story of young Wizard",
                           "https://m.media-amazon.com/images/M/MV5BMTY4NTIwODg0N15BMl5BanBnXkFtZTcwOTc0MjEzMw@@._V1_SY1000_CR0,0,676,1000_AL_.jpg",
                           "https://www.youtube.com/watch?v=o8zKrA5kbNE",
                           "12,April.2002")
titanic = media.Movie("Titanic",
                      "Love story of seventeen year old Rose",
                      "https://images-na.ssl-images-amazon.com/images/I/51Ccrdta4CL._SL500_AC_SS350_.jpg",
                      "https://www.youtube.com/watch?v=2e-eXJ6HgkQ",
                      "18,November,1997")
yeh_jawaani_hai_deewani = media.Movie("Yeh Jawaani Hai Deewani",
                                      "Kabir and Naina bond during a trekking trip. Before Naina can express herself, Kabir leaves India to pursue his career. They meet again years later, but he still cherishes his dreams more than bonds.",
                                      "https://upload.wikimedia.org/wikipedia/en/thumb/1/15/Yeh_jawani_hai_deewani.jpg/220px-Yeh_jawani_hai_deewani.jpg",
                                      "https://www.youtube.com/watch?v=Rbp2XUSeUNE",
                                      "31,May,2013")
purani_jeans = media.Movie("Purani Jeans",
                           "Sam and Sid, two long-time best friends, fall in love with the same woman, Nayantara. What follows is a tragedy with Sam, for which Sid blames himself.",
                           "https://d1t80wr11ktjcz.cloudfront.net/movieposters/v7/AllPhotos/10967212/p10967212_p_v7_aa.jpg?d=270x360&q=60",
                           "https://www.youtube.com/watch?v=Ht0Nj0oxsFo",
                           "2,May,2014")
                                   
#print(it.storyline)
#print (titanic.launch_date)
movie = [tiger_zinda_hai, it, harry_potter, titanic, yeh_jawaani_hai_deewani, purani_jeans]
fresh_tomatoes.open_movies_page(movie)
